/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.java.quis1_c_3088;

/**
 *
 * @author Fikri Fahmi Azim
 * 21103088
 * SI 05 C
 */

import java.io.*;
import java.util.Scanner;

public class Quis1_C_3088 {

    public static void main(String[] args) {
        Nelayan_3088 A[] = new Nelayan_3088[2];
        Dokter_3088 B[] = new Dokter_3088[2];
        Scanner sc = new Scanner(System.in);
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        // Input Nelayan
            for (int i = 0; i < A.length; i++){
                System.out.println("Input Nelayan " + (i + 1));
                A[i] = new Nelayan_3088();
                A[i].inputDataNelayan_3088();
                System.out.println("");
            }   
            
        // Print Data Nelayan
            for (int i = 0; i < A.length; i++){
                A[i].TampilDataNelayan_3088();
                System.out.println("");
            }
        
        // Input Dokter
            for (int i = 0; i < B.length; i++){
                System.out.println("Input Dokter " + (i + 1));
                B[i] = new Dokter_3088();
                B[i].inputDataDokter_3088();
                System.out.println("");
            }
        
        // Print Data Dokter
            for (int i = 0; i < A.length; i++){
                B[i].TampilDataDokter_3088();
                System.out.println("");
            }
            
    }
}
