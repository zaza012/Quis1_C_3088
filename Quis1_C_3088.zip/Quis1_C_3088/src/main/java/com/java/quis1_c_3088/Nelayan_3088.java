/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.java.quis1_c_3088;

/**
 *
 * @author Fikri Fahmi Azim
 * 21103088
 * SI 05 C
 */

public class Nelayan_3088 extends Penduduk_3088 { 
    private int JmlBeratIkan_3088, JmlSolar_3088;
    double TotalPendapatan_3088;
    
    public double TotalPendapatanNelayan_3088(){
        TotalPendapatan_3088 = (JmlBeratIkan_3088 * 8000) - (JmlSolar_3088 * 10000);
        return TotalPendapatan_3088;
    }
    
    public void TampilDataNelayan_3088(){
        System.out.println("=========== DATA NELAYAN ===========");
        tampilDataPenduduk_3088();
        System.out.println("Jumlah Berat Ikan   : " + JmlBeratIkan_3088);
        System.out.println("Jumlah Solar        : " + JmlSolar_3088);
        System.out.println("Total Pendapatan    : Rp " + TotalPendapatanNelayan_3088());
    }
    
    public void inputDataNelayan_3088(){
        super.inputDataPenduduk_3088();
        System.out.println("Jml Berat Ikan      : ");
        JmlBeratIkan_3088 = Integer.parseInt(sc.nextLine());
        System.out.println("Jml Pakai Solar     : ");
        JmlSolar_3088 = Integer.parseInt(sc.nextLine());
    }
}
