/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.java.quis1_c_3088;

/**
 *
 * @author Fikri Fahmi Azim
 * 21103088
 * SI 05 C
 */

public class Dokter_3088 extends Penduduk_3088 {
    private int JmlPasien_3088, JmlObat_3088;
    double TotalPendapatan_3088;
    
    public double TotalPendapatanDokter_3088(){
        TotalPendapatan_3088 = (JmlPasien_3088 * 50000) + (JmlObat_3088 * 10000);
        return TotalPendapatan_3088;
    }
    
    public void TampilDataDokter_3088(){
        System.out.println("=========== DATA DOKTER ===========");
        tampilDataPenduduk_3088();
        System.out.println("Jumlah Pasien       : " + JmlPasien_3088);
        System.out.println("Jumlah Obat         : " + JmlObat_3088);
        System.out.println("Total Pendapatan    : Rp " + TotalPendapatanDokter_3088());
    }
    
    public void inputDataDokter_3088(){
        super.inputDataPenduduk_3088();
        System.out.println("Jml Pasien          : ");
        JmlPasien_3088 = Integer.parseInt(sc.nextLine());
        System.out.println("Jml Obat            : ");
        JmlObat_3088 = Integer.parseInt(sc.nextLine());
    }
}
