/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.java.quis1_c_3088;

/**
 *
 * @author Fikri Fahmi Azim
 * 21103088
 * SI 05 C
 */

import java.util.Scanner;

public class Penduduk_3088 {
    protected String Nik_3088, Nama_3088, Alamat_3088;
    protected int Umur_3088;
    Scanner sc = new Scanner(System.in);
    
    public void tampilDataPenduduk_3088(){
        System.out.println("NIK                 : " + Nik_3088);
        System.out.println("Nama                : " + Nama_3088);
        System.out.println("Umur                : " + Umur_3088);
        System.out.println("Alamat              : " + Alamat_3088);
    }
    
    public void inputDataPenduduk_3088(){
        System.out.println("NIK                 : ");
        Nik_3088 = sc.nextLine();
        System.out.println("Nama                : ");
        Nama_3088 = sc.nextLine();
        System.out.println("Umur                : ");
        Umur_3088 = Integer.parseInt(sc.nextLine());
        System.out.println("Alamat              : ");
        Alamat_3088 = sc.nextLine();
    }
}
